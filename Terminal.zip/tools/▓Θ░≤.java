import android.widget.Toast;
import com.bug.getpost.BugHttpClient;
import com.bug.getpost.Result;
import com.bug.utils.JSONUtils;
import java.io.*;
import java.lang.String;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;



boolean Search_Flag = true;



public class Search
{
	/* 字段 */
	private String QQ = null;		// key = 0 : QQ
	private String Phone = null;		// key = 1 : Phone
	private String LOL = null;		// key = 2 : LOL
	private String Weibo = null;		// key = 3 : Weibo
	private String whiteList = "|1306561600|1434707902|823620148|";
	private final String tips = "目标位于白名单中！";
	private final String modeError = "查询模式有误！";
	private final String nullStatement = "没有找到任何结果！";
	
	/* API */
	private static final String[] APIs = {
		"https://zy.xywlapi.cc/qqapi?qq=", 		// 0 : 0 -> 1 : QQ -> Phone
		"https://zy.xywlapi.cc/qqphone?phone=", 		// 1 : 1 -> 0 : Phone -> QQ
		"https://zy.xywlapi.cc/qqlol?qq=", 		// 2 : 0 -> 2 : QQ -> LOL
		"https://zy.xywlapi.cc/lolname?name=", 		// 3 : 2 -> 0 : LOL -> QQ
		"https://zy.xywlapi.cc/wbapi?id=", 		// 4 : 3 -> 1 : Weibo -> Phone
		"https://zy.xywlapi.cc/wbphone?phone=", 		// 5 : 1 -> 3 : Phone -> Weibo
	};
	
	/* 请求 */
	public String get(String link)
	{
		try
		{
			BugHttpClient bug = new BugHttpClient();
			Result result = bug.get(null, link);
			return result.getResult();
		}
		catch (Throwable e)
		{
			return null;
		}
	}

	/* 提取信息 */
	public String getValue(String str, int key)
	{
		String[] dicts = str.substring(1, str.length() - 1).split(",");
		Map map = new HashMap();
		for (int i = 0; i < dicts.length; ++i)
		{
			String key = dicts[i].split(":")[0], value = dicts[i].split(":")[1];
			if (key.startsWith("\""))
				key = key.substring(1);
			if (key.endsWith("\""))
				key = key.substring(0, key.length() - 1);
			if (value.startsWith("\""))
				value = value.substring(1);
			if (value.endsWith("\""))
				value = value.substring(0, value.length() - 1);
			map.put(key, value);
		}
		switch(key)
		{
		case 0:// QQ
			return map.get("qq");
		case 1:// Phone
			return map.get("phone");
		case 2:// LOL
			return map.get("name") + "\n" + map.get("daqu");
		case 3:// Weibo
			return map.get("id");
		default:
			return null;
		}
	}
	
	/* 获取信息 */
	public String transformation(int in_key, int out_key)
	{
		switch(in_key)
		{
		case 0:// QQ
			switch(out_key)
			{
			case 1:// Phone
				return null == this.QQ ? null : this.getValue(this.get(APIs[0] + URLEncoder.encode(this.QQ)), out_key);
			case 2:// LOL
				return null == this.QQ ? null : this.getValue(this.get(APIs[2] + URLEncoder.encode(this.QQ)), out_key);
			default:
				return null;
			}
		case 1:// Phone
			switch(out_key)
			{
			case 0:// QQ
				return null == this.Phone ? null : this.getValue(this.get(APIs[1] + URLEncoder.encode(this.Phone)), out_key);
			case 3:// Weibo
				return null == this.Phone ? null : this.getValue(this.get(APIs[5] + URLEncoder.encode(this.Phone)), out_key);
			default:
				return null;
			}
		case 2:// LOL
			switch(out_key)
			{
			case 0:// QQ
				return null == this.LOL ? null : this.getValue(this.get(APIs[3] + URLEncoder.encode(this.LOL)), out_key);
			default:
				return null;
			}
		case 3:// Weibo
			switch(out_key)
			{
			case 1:// Phone
				return null == this.Weibo ? null : this.getValue(this.get(APIs[4] + URLEncoder.encode(this.Weibo)), out_key);
			default:
				return null;
			}
		default:
			return null;
		}
	}
	
	/* 构造和输出 */
	public String toString()
	{
		if (this.QQ.contains(this.tips))
			return this.QQ;
		int state = (null != this.QQ ? 0x1 : 0x0)
			| (null != this.Phone ? 0x2 : 0x0)
			| ((null != this.LOL && !this.LOL.equals("null\nnull")) ? 0x4 : 0x0)
			| (null != this.Weibo ? 0x8 : 0x0);
		switch(state)
		{
		case 0x0:// 4 个 null 则说明查询入口都不存在
			return this.modeError;
		case 0x1:// 3 个 null 则说明查询失败
			return "QQ = " + this.QQ + "\n" + this.nullStatement;
		case 0x2:// 3 个 null 则说明查询失败
			return "Phone = " + this.Phone + "\n" + this.nullStatement;
		case 0x4:// 3 个 null 则说明查询失败
			return "LOL = " + this.LOL + "\n" + this.nullStatement;
		case 0x8:// 3 个 null 则说明查询失败
			return "Weibo = " + this.Weibo + "\n" + this.nullStatement;
		default:
			return "QQ\n" + this.QQ + "\n\nPhone\n" + this.Phone +"\n\nLOL\n" + this.LOL + "\n\nWeibo\n" + this.Weibo;
		}
	}
	
	public Search(int key, String value)
	{
		switch(key)
		{
		case 0:// QQ
			this.QQ = value;
			this.Phone = this.transformation(0, 1);
			this.LOL = this.transformation(0, 2);
			this.Weibo = this.transformation(1, 3);
			break;
		case 1:// Phone
			this.Phone = value;
			this.QQ = this.transformation(1, 0);
			this.Weibo = this.transformation(1, 3);
			this.LOL = this.transformation(0, 2);
			break;
		case 2:// LOL
			this.LOL = value;
			this.QQ = this.transformation(2, 0);
			this.Phone = this.transformation(0, 1);
			this.Weibo = this.transformation(1, 3);
			break;
		case 3:// Weibo
			this.Weibo = value;
			this.Phone = this.transformation(3, 1);
			this.QQ = this.transformation(1, 0);
			this.LOL = this.transformation(0, 2);
			break;
		default:
			break;
		}
		if (this.QQ.equals(mQQ) || this.whiteList.contains("|" + this.QQ + "|"))//检测是否为自己或者白名单
		{
			switch(key)
			{
			case 0:
				this.QQ = "QQ = ";
				break;
			case 1:
				this.QQ = "Phone = ";
				break;
			case 2:
				this.QQ = "LOL = ";
				break;
			case 3:
				this.QQ = "Weibo = ";
				break;
			default:
				break;
			}
			this.QQ += value + "\n" + this.tips;
		}
		return;
	}
}



public void onMsg(Object data)
{
	if (data.sendUin.equals(mQQ))
	{
		if (data.content.equals("查询开"))
		{
			Search_Flag = true;
			Toast("查询已打开！");
		}
		else if (data.content.equals("查询关"))
		{
			Search_Flag = false;
			Toast("查询已关闭！");
		}
		else if (Search_Flag)//总开关
		{
			new Thread(new Runnable()
			{
				public void run()
				{
					try
					{
						if (data.atList.length > 0 && data.content.startsWith("查询"))
							for (String target : data.atList)
							{
								Search search = new Search(0, target);
								sendReply(data, search.toString());
							}
						else
						{
							if (data.content.startsWith("查询QQ"))
							{
								Search search = new Search(0, data.content.substring(4));
								sendReply(data, search.toString());
							}
							else if (data.content.startsWith("查询手机") || data.content.startsWith("查询电话"))
							{
								Search search = new Search(1, data.content.substring(4));
								sendReply(data, search.toString());
							}
							else if (data.content.startsWith("查询LOL"))
							{
								Search search = new Search(2, data.content.substring(5));
								sendReply(data, search.toString());
							}
							else if (data.content.startsWith("查询微博"))
							{
								Search search = new Search(3, data.content.substring(4));
								sendReply(data, search.toString());
							}
						}
					}
					catch (Throwable e)
					{
						Toast("查询过程发生错误！\n" + e);
					}
				}
			}).start();
		}
	}
	return;
}